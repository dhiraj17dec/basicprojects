package com.example.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "analysis_data")
public class AnalysisData {

    @Id
    @Column(name = "symbol")
    private String symbol;
    @Column(name = "h_avg1")
    private float h_avg1 ;
    @Column(name = "h_avg2")
    private float h_avg2 ;
    @Column(name = "h_avg3")
    private float h_avg3 ;
    @Column(name = "h_avg4")
    private float h_avg4 ;
    @Column(name = "h_avg5")
    private float  h_avg5 ;
    @Column(name = "h_avg6")
    private float h_avg6 ;
    @Column(name = "h_avg7")
    private float h_avg7 ;
    @Column(name = "h_avg8")
    private float h_avg8 ;
    @Column(name = "h_avg9")
    private float h_avg9 ;
    @Column(name = "h_avg10")
    private float h_avg10 ;
    @Column(name = "h_avg11")
    private float h_avg11 ;
    @Column(name = "h_avg12")
    private float h_avg12 ;
    @Column(name = "h_avg13")
    private float h_avg13 ;
    @Column(name = "h_avg14")
    private float h_avg14 ;
    @Column(name = "h_avg15")
    private float h_avg15 ;
    @Column(name = "h_avg16")
    private float h_avg16 ;
    @Column(name = "l_avg1")
    private float l_avg1 ;
    @Column(name = "l_avg2")
    private float l_avg2 ;
    @Column(name = "l_avg3")
    private float l_avg3 ;
    @Column(name = "l_avg4")
    private float l_avg4 ;
    @Column(name = "l_avg5")
    private float l_avg5 ;
    @Column(name = "l_avg6")
    private float l_avg6 ;
    @Column(name = "l_avg7")
    private float l_avg7 ;
    @Column(name = "l_avg8")
    private float l_avg8 ;
    @Column(name = "l_avg9")
    private float l_avg9 ;
    @Column(name = "l_avg10")
    private float l_avg10 ;
    @Column(name = "l_avg11")
    private float l_avg11 ;
    @Column(name = "l_avg12")
    private float l_avg12 ;
    @Column(name = "l_avg13")
    private float l_avg13 ;
    @Column(name = "l_avg14")
    private float l_avg14 ;
    @Column(name = "l_avg15")
    private float l_avg15 ;
    @Column(name = "l_avg16")
    private float l_avg16 ;
    @Column(name = "avg16_last_txn_gain")
    private float avg16_last_txn_gain ;
    @Column(name = "percent_dev_h_avg")
    private float percent_dev_h_avg ;
    @Column(name = "percent_dev_l_avg")
    private float percent_dev_l_avg ;


	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public float getH_avg1() {
		return h_avg1;
	}
	public void setH_avg1(float h_avg1) {
		this.h_avg1 = h_avg1;
	}
	public float getH_avg2() {
		return h_avg2;
	}
	public void setH_avg2(float h_avg2) {
		this.h_avg2 = h_avg2;
	}
	public float getH_avg3() {
		return h_avg3;
	}
	public void setH_avg3(float h_avg3) {
		this.h_avg3 = h_avg3;
	}
	public float getH_avg4() {
		return h_avg4;
	}
	public void setH_avg4(float h_avg4) {
		this.h_avg4 = h_avg4;
	}
	public float getH_avg5() {
		return h_avg5;
	}
	public void setH_avg5(float h_avg5) {
		this.h_avg5 = h_avg5;
	}
	public float getH_avg6() {
		return h_avg6;
	}
	public void setH_avg6(float h_avg6) {
		this.h_avg6 = h_avg6;
	}
	public float getH_avg7() {
		return h_avg7;
	}
	public void setH_avg7(float h_avg7) {
		this.h_avg7 = h_avg7;
	}
	public float getH_avg8() {
		return h_avg8;
	}
	public void setH_avg8(float h_avg8) {
		this.h_avg8 = h_avg8;
	}
	public float getH_avg9() {
		return h_avg9;
	}
	public void setH_avg9(float h_avg9) {
		this.h_avg9 = h_avg9;
	}
	public float getH_avg10() {
		return h_avg10;
	}
	public void setH_avg10(float h_avg10) {
		this.h_avg10 = h_avg10;
	}
	public float getH_avg11() {
		return h_avg11;
	}
	public void setH_avg11(float h_avg11) {
		this.h_avg11 = h_avg11;
	}
	public float getH_avg12() {
		return h_avg12;
	}
	public void setH_avg12(float h_avg12) {
		this.h_avg12 = h_avg12;
	}
	public float getH_avg13() {
		return h_avg13;
	}
	public void setH_avg13(float h_avg13) {
		this.h_avg13 = h_avg13;
	}
	public float getH_avg14() {
		return h_avg14;
	}
	public void setH_avg14(float h_avg14) {
		this.h_avg14 = h_avg14;
	}
	public float getH_avg15() {
		return h_avg15;
	}
	public void setH_avg15(float h_avg15) {
		this.h_avg15 = h_avg15;
	}
	public float getH_avg16() {
		return h_avg16;
	}
	public void setH_avg16(float h_avg16) {
		this.h_avg16 = h_avg16;
	}
	public float getL_avg1() {
		return l_avg1;
	}
	public void setL_avg1(float l_avg1) {
		this.l_avg1 = l_avg1;
	}
	public float getL_avg2() {
		return l_avg2;
	}
	public void setL_avg2(float l_avg2) {
		this.l_avg2 = l_avg2;
	}
	public float getL_avg3() {
		return l_avg3;
	}
	public void setL_avg3(float l_avg3) {
		this.l_avg3 = l_avg3;
	}
	public float getL_avg4() {
		return l_avg4;
	}
	public void setL_avg4(float l_avg4) {
		this.l_avg4 = l_avg4;
	}
	public float getL_avg5() {
		return l_avg5;
	}
	public void setL_avg5(float l_avg5) {
		this.l_avg5 = l_avg5;
	}
	public float getL_avg6() {
		return l_avg6;
	}
	public void setL_avg6(float l_avg6) {
		this.l_avg6 = l_avg6;
	}
	public float getL_avg7() {
		return l_avg7;
	}
	public void setL_avg7(float l_avg7) {
		this.l_avg7 = l_avg7;
	}
	public float getL_avg8() {
		return l_avg8;
	}
	public void setL_avg8(float l_avg8) {
		this.l_avg8 = l_avg8;
	}
	public float getL_avg9() {
		return l_avg9;
	}
	public void setL_avg9(float l_avg9) {
		this.l_avg9 = l_avg9;
	}
	public float getL_avg10() {
		return l_avg10;
	}
	public void setL_avg10(float l_avg10) {
		this.l_avg10 = l_avg10;
	}
	public float getL_avg11() {
		return l_avg11;
	}
	public void setL_avg11(float l_avg11) {
		this.l_avg11 = l_avg11;
	}
	public float getL_avg12() {
		return l_avg12;
	}
	public void setL_avg12(float l_avg12) {
		this.l_avg12 = l_avg12;
	}
	public float getL_avg13() {
		return l_avg13;
	}
	public void setL_avg13(float l_avg13) {
		this.l_avg13 = l_avg13;
	}
	public float getL_avg14() {
		return l_avg14;
	}
	public void setL_avg14(float l_avg14) {
		this.l_avg14 = l_avg14;
	}
	public float getL_avg15() {
		return l_avg15;
	}
	public void setL_avg15(float l_avg15) {
		this.l_avg15 = l_avg15;
	}
	public float getL_avg16() {
		return l_avg16;
	}
	public void setL_avg16(float l_avg16) {
		this.l_avg16 = l_avg16;
	}
	public float getAvg16_last_txn_gain() {
		return avg16_last_txn_gain;
	}
	public void setAvg16_last_txn_gain(float avg16_last_txn_gain) {
		this.avg16_last_txn_gain = avg16_last_txn_gain;
	}
	public float getPercent_dev_h_avg() {
		return percent_dev_h_avg;
	}
	public void setPercent_dev_h_avg(float percent_dev_h_avg) {
		this.percent_dev_h_avg = percent_dev_h_avg;
	}
	public float getPercent_dev_l_avg() {
		return percent_dev_l_avg;
	}
	public void setPercent_dev_l_avg(float percent_dev_l_avg) {
		this.percent_dev_l_avg = percent_dev_l_avg;
	}
    
    
}