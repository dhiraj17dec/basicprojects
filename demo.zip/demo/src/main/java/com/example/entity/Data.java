package com.example.entity;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "data")
public class Data implements Serializable{

	@Id
	@GeneratedValue
	@Column(name = "id")
	private Long id;
    
    @Column(name = "symbol")
    private String symbol;
    @Column(name = "series")
    private String series;
    @Column(name = "high")
    private float high;
    @Column(name = "low")
    private float low; 
    @Column(name = "open")
    private float open ;
    @Column(name = "close")
    private float close ;
    @Column(name = "last")
    private float last ;
    @Column(name = "prevclose")
    private float prevclose ;
    @Column(name = "tottrdqty")
    private long tottrdqty ;
    @Column(name = "tottrdval")
    private float tottrdval ;
    @Column(name = "date")
    private LocalDate date;
    @Column(name = "totaltrades")
    private long totaltrades;
    @Column(name = "isin")
    private String isin;
    
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getSeries() {
		return series;
	}
	public void setSeries(String series) {
		this.series = series;
	}
	public float getHigh() {
		return high;
	}
	public void setHigh(float high) {
		this.high = high;
	}
	public float getLow() {
		return low;
	}
	public void setLow(float low) {
		this.low = low;
	}
	public float getOpen() {
		return open;
	}
	public void setOpen(float open) {
		this.open = open;
	}
	public float getClose() {
		return close;
	}
	public void setClose(float close) {
		this.close = close;
	}
	public float getLast() {
		return last;
	}
	public void setLast(float last) {
		this.last = last;
	}
	public float getPrevclose() {
		return prevclose;
	}
	public void setPrevclose(float prevclose) {
		this.prevclose = prevclose;
	}
	public long getTottrdqty() {
		return tottrdqty;
	}
	public void setTottrdqty(long tottrdqty) {
		this.tottrdqty = tottrdqty;
	}
	public float getTottrdval() {
		return tottrdval;
	}
	public void setTottrdval(float tottrdval) {
		this.tottrdval = tottrdval;
	}
	
	public 	LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public long getTotaltrades() {
		return totaltrades;
	}
	public void setTotaltrades(long totaltrades) {
		this.totaltrades = totaltrades;
	}
	public String getIsin() {
		return isin;
	}
	public void setIsin(String isin) {
		this.isin = isin;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

}