package com.example.controller;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.entity.AnalysisData;
import com.example.model.Indexes;
import com.example.service.Processor;

@RestController
public class DemoContoller {

	@Autowired
	private Processor service;
	
	private static final String zipPath = "C:\\Users\\admin\\temp\\nse\\";
	private static final String unzipPath = "C:\\Users\\admin\\temp\\nse\\unzip\\";
	
	@GetMapping(value = "/indexes")
	public Indexes getIndexes() {
 
		final String uri = "https://www.nseindia.com/live_market/dynaContent/live_watch/stock_watch/niftyStockWatch.json";
		RestTemplate restTemplate = new RestTemplate();
		Indexes result = restTemplate.getForObject(uri, Indexes.class);
		System.out.println(result);
		return result;
	}

	@GetMapping(value = "/entity")
	public void addEntity() {
		
		System.out.println("Running the Run Method..");
		service.calculate("Reliance");
    	AnalysisData ad = new AnalysisData();
    	ad.setSymbol("Reliance");
//        repository.save(ad);
	}
	
	@GetMapping(value = "/upload")
	public void upload() {
		System.out.println("Running the upload Method..");
		File folder = new File(unzipPath);
        File[] files = folder.listFiles();
        for (File file : files)
        {
            System.out.println("Uploading file : "+ file.getName());
            service.upload(unzipPath + file.getName());
        }
	}
	
	@GetMapping(value = "/calculate")
	public void calculate() {
		System.out.println("Running the calculate Method..");
		service.calculate("Reliance");
	}

	@GetMapping(value = "/unzip")
	public void unzip() {
		System.out.println("Running the unzipFiles Method..");
		File folder = new File(zipPath);
        File[] files = folder.listFiles();
        for (File file : files)
        {
            System.out.println(file.getName());
            if (file.getName().contains(".zip")) {
            	service.unzipFiles(zipPath+file.getName() , unzipPath);
            }
        }
	}

}
