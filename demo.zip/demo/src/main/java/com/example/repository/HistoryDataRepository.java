package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.entity.Data;

public interface HistoryDataRepository extends JpaRepository<Data, String> {

}
