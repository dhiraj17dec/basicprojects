package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.entity.AnalysisData;

public interface AnalysisDataRepository extends JpaRepository<AnalysisData, String> {

}
