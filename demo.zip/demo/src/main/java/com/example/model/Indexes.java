
package com.example.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "declines",
    "data",
    "trdVolumesum",
    "latestData",
    "advances",
    "unchanged",
    "trdValueSumMil",
    "time",
    "trdVolumesumMil",
    "trdValueSum"
})
public class Indexes {

    @JsonProperty("declines")
    private Integer declines;
    @JsonProperty("data")
    private List<Datum> data = null;
    @JsonProperty("trdVolumesum")
    private String trdVolumesum;
    @JsonProperty("latestData")
    private List<LatestDatum> latestData = null;
    @JsonProperty("advances")
    private Integer advances;
    @JsonProperty("unchanged")
    private Integer unchanged;
    @JsonProperty("trdValueSumMil")
    private String trdValueSumMil;
    @JsonProperty("time")
    private String time;
    @JsonProperty("trdVolumesumMil")
    private String trdVolumesumMil;
    @JsonProperty("trdValueSum")
    private String trdValueSum;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("declines")
    public Integer getDeclines() {
        return declines;
    }

    @JsonProperty("declines")
    public void setDeclines(Integer declines) {
        this.declines = declines;
    }

    @JsonProperty("data")
    public List<Datum> getData() {
        return data;
    }

    @JsonProperty("data")
    public void setData(List<Datum> data) {
        this.data = data;
    }

    @JsonProperty("trdVolumesum")
    public String getTrdVolumesum() {
        return trdVolumesum;
    }

    @JsonProperty("trdVolumesum")
    public void setTrdVolumesum(String trdVolumesum) {
        this.trdVolumesum = trdVolumesum;
    }

    @JsonProperty("latestData")
    public List<LatestDatum> getLatestData() {
        return latestData;
    }

    @JsonProperty("latestData")
    public void setLatestData(List<LatestDatum> latestData) {
        this.latestData = latestData;
    }

    @JsonProperty("advances")
    public Integer getAdvances() {
        return advances;
    }

    @JsonProperty("advances")
    public void setAdvances(Integer advances) {
        this.advances = advances;
    }

    @JsonProperty("unchanged")
    public Integer getUnchanged() {
        return unchanged;
    }

    @JsonProperty("unchanged")
    public void setUnchanged(Integer unchanged) {
        this.unchanged = unchanged;
    }

    @JsonProperty("trdValueSumMil")
    public String getTrdValueSumMil() {
        return trdValueSumMil;
    }

    @JsonProperty("trdValueSumMil")
    public void setTrdValueSumMil(String trdValueSumMil) {
        this.trdValueSumMil = trdValueSumMil;
    }

    @JsonProperty("time")
    public String getTime() {
        return time;
    }

    @JsonProperty("time")
    public void setTime(String time) {
        this.time = time;
    }

    @JsonProperty("trdVolumesumMil")
    public String getTrdVolumesumMil() {
        return trdVolumesumMil;
    }

    @JsonProperty("trdVolumesumMil")
    public void setTrdVolumesumMil(String trdVolumesumMil) {
        this.trdVolumesumMil = trdVolumesumMil;
    }

    @JsonProperty("trdValueSum")
    public String getTrdValueSum() {
        return trdValueSum;
    }

    @JsonProperty("trdValueSum")
    public void setTrdValueSum(String trdValueSum) {
        this.trdValueSum = trdValueSum;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
