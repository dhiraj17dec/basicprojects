
package com.example.model;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "indexName",
    "open",
    "high",
    "low",
    "ltp",
    "ch",
    "per",
    "yCls",
    "mCls",
    "yHigh",
    "yLow"
})
public class LatestDatum {

    @JsonProperty("indexName")
    private String indexName;
    @JsonProperty("open")
    private String open;
    @JsonProperty("high")
    private String high;
    @JsonProperty("low")
    private String low;
    @JsonProperty("ltp")
    private String ltp;
    @JsonProperty("ch")
    private String ch;
    @JsonProperty("per")
    private String per;
    @JsonProperty("yCls")
    private String yCls;
    @JsonProperty("mCls")
    private String mCls;
    @JsonProperty("yHigh")
    private String yHigh;
    @JsonProperty("yLow")
    private String yLow;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("indexName")
    public String getIndexName() {
        return indexName;
    }

    @JsonProperty("indexName")
    public void setIndexName(String indexName) {
        this.indexName = indexName;
    }

    @JsonProperty("open")
    public String getOpen() {
        return open;
    }

    @JsonProperty("open")
    public void setOpen(String open) {
        this.open = open;
    }

    @JsonProperty("high")
    public String getHigh() {
        return high;
    }

    @JsonProperty("high")
    public void setHigh(String high) {
        this.high = high;
    }

    @JsonProperty("low")
    public String getLow() {
        return low;
    }

    @JsonProperty("low")
    public void setLow(String low) {
        this.low = low;
    }

    @JsonProperty("ltp")
    public String getLtp() {
        return ltp;
    }

    @JsonProperty("ltp")
    public void setLtp(String ltp) {
        this.ltp = ltp;
    }

    @JsonProperty("ch")
    public String getCh() {
        return ch;
    }

    @JsonProperty("ch")
    public void setCh(String ch) {
        this.ch = ch;
    }

    @JsonProperty("per")
    public String getPer() {
        return per;
    }

    @JsonProperty("per")
    public void setPer(String per) {
        this.per = per;
    }

    @JsonProperty("yCls")
    public String getYCls() {
        return yCls;
    }

    @JsonProperty("yCls")
    public void setYCls(String yCls) {
        this.yCls = yCls;
    }

    @JsonProperty("mCls")
    public String getMCls() {
        return mCls;
    }

    @JsonProperty("mCls")
    public void setMCls(String mCls) {
        this.mCls = mCls;
    }

    @JsonProperty("yHigh")
    public String getYHigh() {
        return yHigh;
    }

    @JsonProperty("yHigh")
    public void setYHigh(String yHigh) {
        this.yHigh = yHigh;
    }

    @JsonProperty("yLow")
    public String getYLow() {
        return yLow;
    }

    @JsonProperty("yLow")
    public void setYLow(String yLow) {
        this.yLow = yLow;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
