
package com.example.model;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "symbol",
    "open",
    "high",
    "low",
    "ltP",
    "ptsC",
    "per",
    "trdVol",
    "trdVolM",
    "ntP",
    "mVal",
    "wkhi",
    "wklo",
    "wkhicm_adj",
    "wklocm_adj",
    "xDt",
    "cAct",
    "previousClose",
    "dayEndClose",
    "iislPtsChange",
    "iislPercChange",
    "yPC",
    "mPC"
})
public class Datum {

    @JsonProperty("symbol")
    private String symbol;
    @JsonProperty("open")
    private String open;
    @JsonProperty("high")
    private String high;
    @JsonProperty("low")
    private String low;
    @JsonProperty("ltP")
    private String ltP;
    @JsonProperty("ptsC")
    private String ptsC;
    @JsonProperty("per")
    private String per;
    @JsonProperty("trdVol")
    private String trdVol;
    @JsonProperty("trdVolM")
    private String trdVolM;
    @JsonProperty("ntP")
    private String ntP;
    @JsonProperty("mVal")
    private String mVal;
    @JsonProperty("wkhi")
    private String wkhi;
    @JsonProperty("wklo")
    private String wklo;
    @JsonProperty("wkhicm_adj")
    private String wkhicmAdj;
    @JsonProperty("wklocm_adj")
    private String wklocmAdj;
    @JsonProperty("xDt")
    private String xDt;
    @JsonProperty("cAct")
    private String cAct;
    @JsonProperty("previousClose")
    private String previousClose;
    @JsonProperty("dayEndClose")
    private String dayEndClose;
    @JsonProperty("iislPtsChange")
    private String iislPtsChange;
    @JsonProperty("iislPercChange")
    private String iislPercChange;
    @JsonProperty("yPC")
    private String yPC;
    @JsonProperty("mPC")
    private String mPC;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("symbol")
    public String getSymbol() {
        return symbol;
    }

    @JsonProperty("symbol")
    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    @JsonProperty("open")
    public String getOpen() {
        return open;
    }

    @JsonProperty("open")
    public void setOpen(String open) {
        this.open = open;
    }

    @JsonProperty("high")
    public String getHigh() {
        return high;
    }

    @JsonProperty("high")
    public void setHigh(String high) {
        this.high = high;
    }

    @JsonProperty("low")
    public String getLow() {
        return low;
    }

    @JsonProperty("low")
    public void setLow(String low) {
        this.low = low;
    }

    @JsonProperty("ltP")
    public String getLtP() {
        return ltP;
    }

    @JsonProperty("ltP")
    public void setLtP(String ltP) {
        this.ltP = ltP;
    }

    @JsonProperty("ptsC")
    public String getPtsC() {
        return ptsC;
    }

    @JsonProperty("ptsC")
    public void setPtsC(String ptsC) {
        this.ptsC = ptsC;
    }

    @JsonProperty("per")
    public String getPer() {
        return per;
    }

    @JsonProperty("per")
    public void setPer(String per) {
        this.per = per;
    }

    @JsonProperty("trdVol")
    public String getTrdVol() {
        return trdVol;
    }

    @JsonProperty("trdVol")
    public void setTrdVol(String trdVol) {
        this.trdVol = trdVol;
    }

    @JsonProperty("trdVolM")
    public String getTrdVolM() {
        return trdVolM;
    }

    @JsonProperty("trdVolM")
    public void setTrdVolM(String trdVolM) {
        this.trdVolM = trdVolM;
    }

    @JsonProperty("ntP")
    public String getNtP() {
        return ntP;
    }

    @JsonProperty("ntP")
    public void setNtP(String ntP) {
        this.ntP = ntP;
    }

    @JsonProperty("mVal")
    public String getMVal() {
        return mVal;
    }

    @JsonProperty("mVal")
    public void setMVal(String mVal) {
        this.mVal = mVal;
    }

    @JsonProperty("wkhi")
    public String getWkhi() {
        return wkhi;
    }

    @JsonProperty("wkhi")
    public void setWkhi(String wkhi) {
        this.wkhi = wkhi;
    }

    @JsonProperty("wklo")
    public String getWklo() {
        return wklo;
    }

    @JsonProperty("wklo")
    public void setWklo(String wklo) {
        this.wklo = wklo;
    }

    @JsonProperty("wkhicm_adj")
    public String getWkhicmAdj() {
        return wkhicmAdj;
    }

    @JsonProperty("wkhicm_adj")
    public void setWkhicmAdj(String wkhicmAdj) {
        this.wkhicmAdj = wkhicmAdj;
    }

    @JsonProperty("wklocm_adj")
    public String getWklocmAdj() {
        return wklocmAdj;
    }

    @JsonProperty("wklocm_adj")
    public void setWklocmAdj(String wklocmAdj) {
        this.wklocmAdj = wklocmAdj;
    }

    @JsonProperty("xDt")
    public String getXDt() {
        return xDt;
    }

    @JsonProperty("xDt")
    public void setXDt(String xDt) {
        this.xDt = xDt;
    }

    @JsonProperty("cAct")
    public String getCAct() {
        return cAct;
    }

    @JsonProperty("cAct")
    public void setCAct(String cAct) {
        this.cAct = cAct;
    }

    @JsonProperty("previousClose")
    public String getPreviousClose() {
        return previousClose;
    }

    @JsonProperty("previousClose")
    public void setPreviousClose(String previousClose) {
        this.previousClose = previousClose;
    }

    @JsonProperty("dayEndClose")
    public String getDayEndClose() {
        return dayEndClose;
    }

    @JsonProperty("dayEndClose")
    public void setDayEndClose(String dayEndClose) {
        this.dayEndClose = dayEndClose;
    }

    @JsonProperty("iislPtsChange")
    public String getIislPtsChange() {
        return iislPtsChange;
    }

    @JsonProperty("iislPtsChange")
    public void setIislPtsChange(String iislPtsChange) {
        this.iislPtsChange = iislPtsChange;
    }

    @JsonProperty("iislPercChange")
    public String getIislPercChange() {
        return iislPercChange;
    }

    @JsonProperty("iislPercChange")
    public void setIislPercChange(String iislPercChange) {
        this.iislPercChange = iislPercChange;
    }

    @JsonProperty("yPC")
    public String getYPC() {
        return yPC;
    }

    @JsonProperty("yPC")
    public void setYPC(String yPC) {
        this.yPC = yPC;
    }

    @JsonProperty("mPC")
    public String getMPC() {
        return mPC;
    }

    @JsonProperty("mPC")
    public void setMPC(String mPC) {
        this.mPC = mPC;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
