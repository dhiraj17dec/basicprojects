package com.example.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

//www.java67.com/2015/08/how-to-load-data-from-csv-file-in-java.html#ixzz5p2p8KeY5

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.AnalysisData;
import com.example.entity.Data;
import com.example.repository.AnalysisDataRepository;
import com.example.repository.HistoryDataRepository;

@Service
public class Processor {

	@Autowired
	private AnalysisDataRepository analysisRepository;

	@Autowired
	private HistoryDataRepository dr;

	private static boolean isDateFormatted = false;
	
	public void calculate(String symbol) {

		System.out.println("Running the calulate Method..");

		AnalysisData ad = new AnalysisData();
		ad.setSymbol(symbol);
		
//		Optional<Data> data = (Optional<Data>) dr.findBySymbol(symbol);
		System.out.println("Obtained data in the calulate Method..");
		//    	data.
		//    	ad.setH_avg16(h_avg16);
		//    	ad.setL_avg16(l_avg16);
		//    	
		//        repository.save(ad);

	};

	public void upload(String fileName) {
		isDateFormatted= false;
		readDataFromCSV(fileName);
	};
	
	public static void unzipFiles(String fileZip, String unzipPath){
		File destDir = new File(unzipPath);
		byte[] buffer = new byte[1024];
		
		try {
			ZipInputStream zis = new ZipInputStream(new FileInputStream(fileZip));
			ZipEntry zipEntry = zis.getNextEntry();
			while (zipEntry != null) {
				File newFile = newFile(destDir, zipEntry);
				FileOutputStream fos = new FileOutputStream(newFile);
				int len;
				while ((len = zis.read(buffer)) > 0) {
					fos.write(buffer, 0, len);
				}
				fos.close();
				zipEntry = zis.getNextEntry();
			}
			zis.closeEntry();
			zis.close();
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	public static File newFile(File destinationDir, ZipEntry zipEntry) throws IOException {
		File destFile = new File(destinationDir, zipEntry.getName());

		String destDirPath = destinationDir.getCanonicalPath();
		String destFilePath = destFile.getCanonicalPath();

		if (!destFilePath.startsWith(destDirPath + File.separator)) {
			throw new IOException("Entry is outside of the target dir: " + zipEntry.getName());
		}

		return destFile;
	}
	
	private String getDateFormat(String date) {
		isDateFormatted = true;
		if(date.contains("jan")) return date.replace("-jan-","-Jan-");
		else if(date.contains("feb")) return date.replace("-feb-","-Feb-");
		else if(date.contains("mar")) return date.replace("-mar-","-Mar-");
		else if(date.contains("apr")) return date.replace("-apr-","-Apr-");
		else if(date.contains("may")) return date.replace("-may-","-May-");
		else if(date.contains("jun")) return date.replace("-jun-","-Jun-");
		else if(date.contains("jul")) return date.replace("-jul-","-Jul-");
		else if(date.contains("aug")) return date.replace("-aug-","-Aug-");
		else if(date.contains("sep")) return date.replace("-sep-","-Sep-");
		else if(date.contains("oct")) return date.replace("-oct-","-Oct-");
		else if(date.contains("nov")) return date.replace("-nov-","-Nov-");
		else if(date.contains("dec")) return date.replace("-dec-","-Dec-");
		else return date;
	}
	private void readDataFromCSV(String fileName) {
		String date = "";
		Path pathToFile = Paths.get(fileName); // create an instance of BufferedReader // using try with resource, Java 7 feature to close resources 
		System.out.println(pathToFile);
		String[] attributes; 
		try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.US_ASCII)) { 
			// read the first line from the text file
			br.readLine(); 
			String line = br.readLine();
			
			// loop until all lines are read 
			while (line != null) { 
				attributes = line.split(","); 
				
				if(attributes[1].equalsIgnoreCase("EQ")) {
					if(!isDateFormatted) {
						date = attributes[10].toLowerCase();
						date = getDateFormat(date);	
					}	
					System.out.println(attributes.length);
					System.out.println(attributes[0]+","+attributes[1]+","+attributes[2]+","+attributes[3]+","+attributes[4]+","+attributes[5]+","+attributes[6]+","+attributes[7]+","+attributes[8]+","+attributes[9]+","+attributes[10]+","+attributes[11]+","+attributes[12]);
					System.out.println(date);
					Data data = new Data(); 
					//SYMBOL,SERIES,OPEN,HIGH,LOW,CLOSE,LAST,PREVCLOSE,TOTTRDQTY,TOTTRDVAL,TIMESTAMP,TOTALTRADES,ISIN,
					data.setSymbol(attributes[0]);data.setSeries(attributes[1]);data.setOpen(Float.parseFloat(attributes[2]));data.setHigh(Float.parseFloat(attributes[3]));
					data.setLow(Float.parseFloat(attributes[4])); data.setClose(Float.parseFloat(attributes[5]));data.setLast(Float.parseFloat(attributes[6]));
					data.setPrevclose(Float.parseFloat(attributes[7]));data.setTottrdqty(Long.parseLong(attributes[8]));data.setTottrdval(Float.parseFloat(attributes[9]));
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d-MMM-yyyy");
					data.setDate(LocalDate.parse(date, formatter)); data.setTotaltrades(Long.parseLong(attributes[11]));data.setIsin(attributes[12]);
					dr.save(data);
				}
				line = br.readLine(); 
				
				} 
			} catch (IOException ioe) { 
				ioe.printStackTrace(); 
				
			} 
	}
			
}
