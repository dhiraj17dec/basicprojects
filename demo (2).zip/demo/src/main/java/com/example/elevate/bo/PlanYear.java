package com.example.elevate.bo;

import java.io.Serializable;
import java.util.Objects;

public class PlanYear implements Serializable {

    private long id;
    private String name;
    private boolean iscurrent;

    public PlanYear() {
    }

    public PlanYear(long id, String name, boolean iscurrent) {
        this.id = id;
        this.name = name;
        this.iscurrent = iscurrent;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isIscurrent() {
        return iscurrent;
    }

    public void setIscurrent(boolean iscurrent) {
        this.iscurrent = iscurrent;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PlanYear planYear = (PlanYear) o;
        return id == planYear.id &&
                iscurrent == planYear.iscurrent &&
                Objects.equals(name, planYear.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, iscurrent);
    }

}
