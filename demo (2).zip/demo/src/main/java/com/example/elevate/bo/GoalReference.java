package com.example.elevate.bo;

import java.io.Serializable;
import java.util.Objects;

public class GoalReference implements Serializable {

    private String businessPlanYearId;
    private GoalItem goalItem;
    private GoalMetricItem goalMetricItem;
    private GoalAction goalAction;

    public GoalReference() {
    }

    public GoalReference(String businessPlanYearId, GoalItem goalItem, GoalMetricItem goalMetricItem, GoalAction goalAction) {
        this.businessPlanYearId = businessPlanYearId;
        this.goalItem = goalItem;
        this.goalMetricItem = goalMetricItem;
        this.goalAction = goalAction;
    }

    public String getBusinessPlanYearId() {
        return businessPlanYearId;
    }

    public void setBusinessPlanYearId(String businessPlanYearId) {
        this.businessPlanYearId = businessPlanYearId;
    }

    public GoalItem getGoalItem() {
        return goalItem;
    }

    public void setGoalItem(GoalItem goalItem) {
        this.goalItem = goalItem;
    }

    public GoalMetricItem getGoalMetricItem() {
        return goalMetricItem;
    }

    public void setGoalMetricItem(GoalMetricItem goalMetricItem) {
        this.goalMetricItem = goalMetricItem;
    }

    public GoalAction getGoalAction() {
        return goalAction;
    }

    public void setGoalAction(GoalAction goalAction) {
        this.goalAction = goalAction;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GoalReference that = (GoalReference) o;
        return Objects.equals(businessPlanYearId, that.businessPlanYearId) &&
                Objects.equals(goalItem, that.goalItem) &&
                Objects.equals(goalMetricItem, that.goalMetricItem) &&
                Objects.equals(goalAction, that.goalAction);
    }

    @Override
    public int hashCode() {
        return Objects.hash(businessPlanYearId, goalItem, goalMetricItem, goalAction);
    }
}
