package com.example.elevate.controller;


import com.example.elevate.bo.BusinessPlan;
import com.example.elevate.bo.GoalReference;
import com.example.elevate.service.BusinessPlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@EnableAutoConfiguration

public class BusinessPlanController {

    @Autowired
    public BusinessPlanService service;

    @RequestMapping(value = "/planYears/{planYearsId}/businessPlans", method = RequestMethod.GET)
    @ResponseBody
    public List<BusinessPlan> listBusinessPlan(@PathVariable("planYearsId") String planYearId, String userId ){
        return service.getBusinessPlans(planYearId, userId);
    }

    @RequestMapping(value="/planYears/{businessPlanYearId}/listGoalReferences")
    @ResponseBody
    public  List<GoalReference> listGoalReferences(@PathVariable("businessPlanYearId") String businessPlanYearId ){
        return service.getGoalReferences(businessPlanYearId);
    }
}
