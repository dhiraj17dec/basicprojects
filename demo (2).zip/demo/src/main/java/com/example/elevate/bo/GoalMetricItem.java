package com.example.elevate.bo;

import java.io.Serializable;

public class GoalMetricItem implements Serializable {



}
