package com.example.elevate.service;

import com.example.elevate.bo.BusinessPlan;
import com.example.elevate.bo.GoalReference;
import com.example.elevate.dao.BusinessPlanDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BusinessPlanService {

    @Autowired
    private BusinessPlanDao businessPlanDao;

    public List<BusinessPlan> getBusinessPlans(String id, String userId){

        return businessPlanDao.getBusinessPlans(id,userId);

    }

    public List<GoalReference> getGoalReferences(String id){

        return businessPlanDao.getGoalReferences(id);

    }

}
