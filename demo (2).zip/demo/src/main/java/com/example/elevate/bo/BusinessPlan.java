package com.example.elevate.bo;

import java.io.Serializable;
import java.util.Objects;

public class BusinessPlan implements Serializable {


    private long id;
    private String planYearId;
    private String comment;
    private String vision;

    public BusinessPlan() {
    }

    public BusinessPlan(long id, String planYearId, String comment, String vision) {
        this.id = id;
        this.planYearId = planYearId;
        this.comment = comment;
        this.vision = vision;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPlanYearId() {
        return planYearId;
    }

    public void setPlanYearId(String planYearId) {
        this.planYearId = planYearId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getVision() {
        return vision;
    }

    public void setVision(String vision) {
        this.vision = vision;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BusinessPlan that = (BusinessPlan) o;
        return id == that.id &&
                Objects.equals(planYearId, that.planYearId) &&
                Objects.equals(comment, that.comment) &&
                Objects.equals(vision, that.vision);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, planYearId, comment, vision);
    }
}
