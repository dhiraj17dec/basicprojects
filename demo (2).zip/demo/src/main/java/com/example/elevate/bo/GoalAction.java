package com.example.elevate.bo;

import java.io.Serializable;

public class GoalAction implements Serializable {

}
