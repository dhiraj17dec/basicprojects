package com.example.elevate.dao;

import com.example.elevate.bo.BusinessPlan;
import com.example.elevate.bo.GoalReference;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class BusinessPlanDao {

    public List<BusinessPlan> getBusinessPlans(String id, String userName){
        List<BusinessPlan> plans = new ArrayList<BusinessPlan>();
        plans.add(new BusinessPlan(1,"2016", "comment1","vision1"));
        plans.add(new BusinessPlan(2,"2017", "comment2","vision2"));
        plans.add(new BusinessPlan(3,"2018", "comment3","vision3"));
        return plans;
    }

    public List<GoalReference> getGoalReferences(String id){
        List<GoalReference> goalReferences = new ArrayList<GoalReference>();
        goalReferences.add(new GoalReference());
        goalReferences.add(new GoalReference());
        goalReferences.add(new GoalReference());
        return goalReferences;
    }
}
